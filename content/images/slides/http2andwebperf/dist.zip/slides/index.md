
# Myth busters - HTTP/2 and web performance

From the terminal, pop in:

  ```yo reveal:slide "Slide Title"```

Available options:

 ```--markdown --attributes --notes```
